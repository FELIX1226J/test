import json
import asyncio
import os
import discord
from discord import Message, Guild, TextChannel
from discord.ext import commands
import datetime

bot = commands.Bot(command_prefix='a!', help_command=None)

if os.path.isfile("servers.json"):
    with open('servers.json', encoding='utf-8') as f:
        servers = json.load(f)
else:
    servers = {"servers": []}
    with open('servers.json', 'w') as f:
        json.dump(servers, f, indent=4)

@bot.event
async def on_ready():
  print(f'{bot.user} ist nun online!')
  print(f'{bot.user.id}')

@bot.event
async def on_guild_join(guild):
    print(f'Bot auf Server {guild.name} hinzugefügt!')
    channel = bot.get_channel(879701344670334997)
    if channel:
      embed = discord.Embed(
        title='Bot auf Server hinzugefügt!',
        description=f'Server Name: {guild.name}\nServer ID: {guild.id}\nAnzahl an Mitgliedern: {guild.member_count}\n\n**Neue Anzahl an Servern: {len(bot.guilds)}**'
      )
      embed.set_thumbnail(url=f'{guild.icon_url}')
      await channel.send(embed=embed)

@bot.event
async def on_guild_remove(guild):
    print(f'Bot auf Server {guild.name} entfernt!')
    channel = bot.get_channel(873633549209722942)
    if channel:
      embed = discord.Embed(
        title='Bot auf Server entfernt!',
        description=f'Server Name: {guild.name}\nServer ID: {guild.id}\nAnzahl an Mitgliedern: {guild.member_count}\n\n**Neue Anzahl an Servern: {len(bot.guilds)}**'
      )
      embed.set_thumbnail(url=f'{guild.icon_url}')
      await channel.send(embed=embed)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.NotOwner):
        msg = await ctx.send(f'```py\n{error}```')
        await msg.delete(delay=5)
        await ctx.message.delete(delay=7)
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send('Dieser Befehl existiert nicht.')
    else:
        raise error

@bot.command()
@commands.bot_has_permissions(manage_messages = True, manage_channels = True)
async def addGlobal(ctx):
    if ctx.author.guild_permissions.administrator:
        if not guild_exists(ctx.guild.id):
            server = {
                "guildid": ctx.guild.id,
                "channelid": ctx.channel.id,
                "invite": f'{(await ctx.channel.create_invite()).url}'
            }
            servers["servers"].append(server)
            with open('servers.json', 'w') as f:
                json.dump(servers, f, indent=4)
            embed = discord.Embed(title="**Willkommen im GlobalChat Felix Develepor™**",
                                  description="Dein Server ist einsatzbereit!"
                                              " Ab jetzt werden alle Nachrichten in diesem Channel direkt an alle"
                                              " anderen Server weitergeleitet!",
                                  color=0x2ecc71)
            embed.set_footer(text='Bitte beachte, dass im GlobalChat stets ein Slowmode von mindestens 5 Sekunden'
                                  ' gesetzt sein sollte.')
            await ctx.send(embed=embed)
            await sendAllWillkommen(ctx)
            await ctx.channel.edit(slowmode_delay=5)
        else:
            embed = discord.Embed(description="Du hast bereits einen GlobalChat auf deinem Server.\r\n"
                                              "Bitte beachte, dass jeder Server nur einen GlobalChat besitzen kann.",
                                  color=0x2ecc71)
            await ctx.send(embed=embed)


@bot.command()
async def removeglobal(ctx):
  if ctx.author.guild_permissions.administrator:
      if guild_exists(ctx.guild.id):
          globalid = get_globalChat_id(ctx.guild.id)
          if globalid != -1:
              servers["servers"].pop(globalid)
              with open('servers.json', 'w') as f:
                  json.dump(servers, f, indent=4)
          await ctx.send('Der  Globalchat wurde nun entfernt. Mit !addGlobal kann er erneut aktiviert werden.')


#########################################

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if not message.content.startswith('!'):
        if get_globalChat(message.guild.id, message.channel.id):
            await sendAll(message)
    await bot.process_commands(message)


#########################################

async def sendAll(message: Message):
    embed = discord.Embed(
    title=f"{message.author.name}", 
    description=message.content, 
    color=0x00fff6,
    timestamp=datetime.datetime.utcnow())
    embed.set_footer(text=f'{message.guild.name} | {message.guild.member_count} User',
    icon_url=f'{message.guild.icon_url}')
    embed.set_thumbnail(url=message.author.avatar_url)
    embed.add_field(name=f'⠀', value='⠀', inline=False)
    


    for server in servers["servers"]:
        guild: Guild = bot.get_guild(int(server["guildid"]))
        if guild:
            channel: TextChannel = guild.get_channel(int(server["channelid"]))
            if channel:
                await channel.send(embed=embed)
    await message.delete()

###################################


async def sendAllWillkommen(ctx):
    embed = discord.Embed(
    title=f"Willkommen!", 
    description=f'Der Server {ctx.guild.name} hat den Bot nun hinzugefügt!', 
    color=0x00fff6,
    timestamp=datetime.datetime.utcnow())
    embed.set_footer(text=f'{ctx.guild.name} | {ctx.guild.member_count} User',
    icon_url=f'{ctx.guild.icon_url}')
    embed.set_thumbnail(url=ctx.author.avatar_url)
    embed.add_field(name=f'⠀', value='⠀', inline=False)
    embed.add_field(name=f'Support & Bot⠀', value=f'[Support Server](https://discord.gg/KmkzC9Ye)・[Bot invite](https://discord.com/api/oauth2/authorize?client_id=871470882848116816&permissions=8&scope=bot)', inline=False)

    for server in servers["servers"]:
        guild: Guild = bot.get_guild(int(server["guildid"]))
        if guild:
            channel: TextChannel = guild.get_channel(int(server["channelid"]))
            if channel:
                await channel.send(embed=embed)
    await ctx.message.delete()


###############################

def guild_exists(guildid):
    for server in servers['servers']:
        if int(server['guildid'] == int(guildid)):
            return True
    return False


def get_globalChat(guild_id, channelid=None):
    globalChat = None
    for server in servers["servers"]:
        if int(server["guildid"]) == int(guild_id):
            if channelid:
                if int(server["channelid"]) == int(channelid):
                    globalChat = server
            else:
                globalChat = server
    return globalChat


def get_globalChat_id(guild_id):
    globalChat = -1
    i = 0
    for server in servers["servers"]:
        if int(server["guildid"]) == int(guild_id):
            globalChat = i
        i += 1
    return globalChat


###########################################################

@bot.command()
async def help(ctx):
    helpEmbed = discord.Embed(title=f"Global Commands", color=discord.Color.red())

    helpEmbed.add_field(name="setchannel", value=f"Setze den Kanal für den Global")

    helpEmbed.add_field(name=f"")




bot.run('ODc5Njk2Mjg5MzA5MjgyMzQ0.YSTfAw.tyfsaZBnfnne0PZdmgN5VrOgxGM')